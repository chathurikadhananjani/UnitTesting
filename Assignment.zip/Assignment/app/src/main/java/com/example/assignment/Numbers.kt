package com.example.assignment
import kotlin.math.*

class Numbers {
    fun additionOperator(number1: Int, number2: Int): Int {
        return number1 + number2
    }
    fun subtractionOperator(number1: Int, number2: Int): Int {
        return number1 - number2
    }
    fun multiplicationOperator(number1: Int, number2: Int): Int {
        return number1 * number2
    }
    fun divisionOperator(number1: Int, number2: Int): Int {
        return number1 / number2
    }


    fun powerOf(number: Int): Int {
        return number * number
    }

}