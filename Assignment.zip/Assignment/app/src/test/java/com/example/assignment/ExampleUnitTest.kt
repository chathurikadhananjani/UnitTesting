package com.example.assignment

import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    lateinit var numbers: Numbers
    @Before
    fun setUpCalculator(){
        numbers = Numbers()
    }
    @Test
    //Adding two positive integers
    fun addition_of_two_positive_numbers() {
        val sum = numbers.additionOperator(1, 1)
        assertEquals(2, sum)
    }

    @Test
    //Adding two negative integers
    fun addition_of_two_negative_numbers() {
        val sum = numbers.additionOperator(-1, -2)
        assertEquals(-3, sum)
    }

    @Test
    //Adding a smaller negative integer and a larger positive integer
    fun addition_of_negative_and_positive() {
        val sum = numbers.additionOperator(-1, +2)
        assertEquals(1, sum)
    }

    @Test
    //Adding a smaller positive integer and a larger negative integer
    fun addition_of_positive_and_negative() {
        val sum = numbers.additionOperator(2, -3)
        assertEquals(-1, sum)
    }

    @Test
    //Adding a positive integer and zero
    fun addition_of_positive_with_zero() {
        val sum = numbers.additionOperator(1, 0)
        assertEquals(1, sum)
    }

    @Test
    //Adding a negative integer and zero
    fun addition_of_negative_with_zero() {
        val sum = numbers.additionOperator(-1, 0)
        assertEquals(-1, sum)
    }

    @Test
    //Subtraction of two positive integers
    fun subtraction_of_two_positive_numbers() {
        val sum = numbers.subtractionOperator(2,1)
        assertEquals(1, sum)
    }
    @Test
    //subtraction two negative integers
    fun subtraction_of_two_negative_numbers() {
        val sum = numbers.subtractionOperator(-1,-2)
        assertEquals(1, sum)
    }

    @Test

    fun subtraction_of_negative_and_positive() {
        val sum = numbers.subtractionOperator(-1, +2)
        assertEquals(1, sum)
    }

    @Test
    fun subtraction_of_positive_and_negative() {
        val sum = numbers.subtractionOperator(2, -3)
        assertEquals(5, sum)
    }




}